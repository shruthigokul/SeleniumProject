
public class Constants {

	public static FINAL String url="http://alchemy.hguy.co/orangehrm";
	
}
