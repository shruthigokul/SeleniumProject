package BaseClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.PublicKey;
import java.sql.Driver;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class BaseClass {

	
	
	
	protected static WebDriver driver;
	protected static Properties properties;
	protected static FileInputStream inStream;
	
	
	public void getPropValues() throws IOException {
		//Loading 
		properties = new Properties();
		inStream = new FileInputStream("C:\\Users\\ShruthiGokul\\eclipse-workspace\\FrameSelenium\\resources\\input.properties");
		properties.load(inStream);
		}
	
	public void OpenBrowser(String browserName)
	{
		switch(browserName.toUpperCase())
		{
		case "IE": {
			System.setProperty("webdriver.ie.driver","C:\\Users\\ShruthiGokul\\Downloads\\IEDriverServer_x64_3.150.1\\IEDriverServer.exe");
	     	driver=new InternetExplorerDriver();
		}
		break;
		case "CHROME": {
			System.setProperty("webdriver.chrome.driver","C:\\Users\\ShruthiGokul\\chromedriver.exe");
	     	driver=new ChromeDriver();
	     	System.out.println("chrome browser opened");
		}
		break;
		case "FIREFOX":
		{
			{
				System.setProperty("webdriver.gecko.driver","C:\\Users\\ShruthiGokul\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");
		     	driver=new FirefoxDriver();
			}
			break;
		}
		default:{
			System.out.println("Browser name is invalid");
			break;
			}
		}	
		
      //to maximise windows
		driver.manage().window().maximize();

	}



	public void gotoURL(String url)
	{
	driver.get(url);
	}

	public void clickElement(WebElement element)
	{
	element.click();
	}

	public void enteringText(WebElement element,String valueToBeEntered)
	{
	element.sendKeys(valueToBeEntered);
	}

	public WebElement findElement(String xpath)
	{
	WebElement element=driver.findElement(By.xpath(xpath));
	return element;
	}

	public List<WebElement> findElements(String xpath)
	{
	List<WebElement> element=driver.findElements(By.xpath(xpath));
	return element;
	}

	public boolean isElementPresent(List<WebElement> elements)
	{
	if(elements.size()>0)
	{
		return true;
	}
	else {
		return false;
	}
	
}

	public void perofrmAction(WebElement element)
	{
		Actions action=new Actions(driver);
		action.moveToElement(element).perform();
		
	}
	
	public void selectFromDropdown(WebElement element,String Value)
	{
		Select ddSelect=new Select(element);
		ddSelect.selectByVisibleText(Value);
	}
	
	public void clearTextBox(WebElement element)
	{
		element.clear();
	}


}


