package HRMTestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseClass.BaseClass;

public class Activity8 extends BaseClass{

	
	
Properties properties=null;
	
	@BeforeTest()
	public void initialising() throws IOException
	{
		properties = new Properties();
		inStream = new FileInputStream("C:\\Users\\ShruthiGokul\\eclipse-workspace\\FrameSelenium\\resources\\input.properties");
		properties.load(inStream);
		OpenBrowser("FIREFOX");
		gotoURL(properties.getProperty("url"));
	}
	
	@Test()
	public  void headerImagetest() throws InterruptedException {
	
		//find and enter credentials in username and passowrd field
		enteringText(findElement(properties.getProperty("username_xpath")), properties.getProperty("username"));
		enteringText(findElement(properties.getProperty("password_xpath")), properties.getProperty("password"));
				
		//click login button
		clickElement(findElement(properties.getProperty("loginbtn_xpath")));
				
		
		//Click on Dashboard
		clickElement(findElement("//a[@id='menu_dashboard_index']"));
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.elementToBeClickable(findElement("//a[contains(@href,'applyLeave')]")));
		
		//clicking emergency contact link
		 findElement("//a[contains(@href,'applyLeave')]").click();
		 
		//fetch all employee names from result table
			List<WebElement> elements=findElements("//table[@id='emgcontact_list']/tbody/tr");
			List<WebElement> columns=findElements("//table[@id='emgcontact_list']/thead/tr/th");
			
			for(int i=1;i<=elements.size();i++)
			{
				Reporter.log("EmergencyContact("+i+")\n",true);
				for(int j=2;j<=columns.size();j++)
				{
					//fetching and displaying list of emergency contacts
					String headername=findElement("//table[@id='emgcontact_list']/thead/tr/th["+j+"]").getAttribute("innerText");
					String val=findElement("//table[@id='emgcontact_list']/tbody/tr["+i+"]/td["+j+"]").getAttribute("innerText");
					
					Reporter.log(headername+" : "+val+"\n",true);
				}
				
				
			}
		 
		 
		 
			
	}
	
	@AfterTest()
	public void endTest()
	{
		driver.quit();
	}
}
