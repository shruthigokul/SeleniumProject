package HRMTestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseClass.BaseClass;

public class Activity2 extends BaseClass{

	

	Properties properties=null;
	
	@BeforeTest()
	public void initialising() throws IOException
	{
		properties = new Properties();
		inStream = new FileInputStream("C:\\Users\\ShruthiGokul\\eclipse-workspace\\FrameSelenium\\resources\\input.properties");
		properties.load(inStream);
		OpenBrowser("FIREFOX");
		gotoURL(properties.getProperty("url"));
	}
	
	@Test()
	public  void headerImagetest() {
		
		//get the url of header image and print it in console
		System.out.println(findElement(properties.getProperty("image_xpath")).getAttribute(properties.getProperty("findAttributeForImageLink")));
		
	}
	
	@AfterTest()
	public void endTest()
	{
		driver.quit();
	}
	
}
