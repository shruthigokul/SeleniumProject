package HRMTestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.server.handler.ClickElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseClass.BaseClass;

public class Activity5 extends BaseClass{
	
	Properties properties=null;
	
	@BeforeTest()
	public void initialising() throws IOException
	{
		properties = new Properties();
		inStream = new FileInputStream("C:\\Users\\ShruthiGokul\\eclipse-workspace\\FrameSelenium\\resources\\input.properties");
		properties.load(inStream);
		OpenBrowser("FIREFOX");
		gotoURL(properties.getProperty("url"));
	}
	
	@Test()
	public  void headerImagetest() throws InterruptedException {
	
		//find and enter credentials in username and passowrd field
		enteringText(findElement(properties.getProperty("username_xpath")), properties.getProperty("username"));
		enteringText(findElement(properties.getProperty("password_xpath")), properties.getProperty("password"));
				
		//click login button
		clickElement(findElement(properties.getProperty("loginbtn_xpath")));
				
		
		//Click on my info
		clickElement(findElement("//a[@id='menu_pim_viewMyDetails']"));
		
		
		Thread.sleep(5000);
		//Click on Edit button
		clickElement(findElement("//input[@id='btnSave']"));
		
		//Enter details in Firstname, Middle Name, Last name
		
		//clearing the values in Firstname field and entering values in it
		clearTextBox(findElement("//input[@id='personal_txtEmpFirstName']"));
		
		enteringText(findElement("//input[@id='personal_txtEmpFirstName']"), "James");
		
		//clearing the values in middlename field and entering values in it
		clearTextBox(findElement("//input[@id='personal_txtEmpMiddleName']"));
		
		enteringText(findElement("//input[@id='personal_txtEmpMiddleName']"), "J");
		
		
		//clearing the values in lastname field and entering values in it
		clearTextBox(findElement("//input[@id='personal_txtEmpLastName']"));
		
		enteringText(findElement("//input[@id='personal_txtEmpLastName']"), "Bond");
		
		String gender="Female";
		//Change the gender
		if(gender=="Male")
		{
			clickElement(findElement("//input[@id='personal_optGender_1']"));
		}
		else if(gender=="Female"){
			{
				clickElement(findElement("//input[@id='personal_optGender_2']"));
			}
		}
		
		
		//Selecting value from Nationality dropdown
		selectFromDropdown(findElement("//select[@id='personal_cmbNation']"),"Austrian");

		//Selecting DOB from date picker
		//Clicking Date of Birth Date picker
		clickElement(findElement("//input[@id='personal_DOB']"));
		
		
		Thread.sleep(5000);
		//Selecting value from Monthdropdown
		selectFromDropdown(findElement("//select[@class='ui-datepicker-month']"),"Aug");
		
		//Selecting value from Year dropdown
		selectFromDropdown(findElement("//select[@class='ui-datepicker-year']"),"1990");
		
		//Selecting date from calender
		clickElement(findElement("//table[@class='ui-datepicker-calendar']/tbody/tr/td/a[text()='2']"));
		
	
		
	}
	
	@AfterTest()
	public void endTest()
	{
		driver.quit();
	}

}
