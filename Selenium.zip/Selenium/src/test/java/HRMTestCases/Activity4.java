package HRMTestCases;

import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseClass.BaseClass;

public class Activity4 extends BaseClass{
	
	Properties properties=null;
	
	@BeforeTest()
	public void initialising() throws IOException
	{
		properties = new Properties();
		inStream = new FileInputStream("C:\\Users\\ShruthiGokul\\eclipse-workspace\\FrameSelenium\\resources\\input.properties");
		properties.load(inStream);
		OpenBrowser("FIREFOX");
		gotoURL(properties.getProperty("url"));
	}
	
	@Test()
	public  void headerImagetest() throws InterruptedException {
	
		//find and enter credentials in username and passowrd field
		enteringText(findElement(properties.getProperty("username_xpath")), properties.getProperty("username"));
		enteringText(findElement(properties.getProperty("password_xpath")), properties.getProperty("password"));
				
		//click login button
		clickElement(findElement(properties.getProperty("loginbtn_xpath")));
				
		
		//hover over PIM
		perofrmAction(findElement("//a[@id='menu_pim_viewPimModule']"));
		
		//Click on Add employee link
		clickElement(findElement("//a[@id='menu_pim_addEmployee']"));
		
		Thread.sleep(5000);
		
		
		//Enter the required details and click on save button
		enteringText(findElement("//input[@id='firstName']"),"Green");
		enteringText(findElement("//input[@id='lastName']"),"Yellow");
		clickElement(findElement("//input[@id='btnSave']"));
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		//wait.until visibility of the element Edit button in personal details page
		wait.until(ExpectedConditions.visibilityOf(findElement("//input[@value='Edit']")));
		
		//Click admin link
		clickElement(findElement("//a[@id='menu_admin_viewAdminModule']"));
		
		//fetch all employee names from result table
		List<WebElement> elements=findElements("//table[@id='resultTable']/tbody/tr");
		List<String> employeeName=new ArrayList<String>();
		for(int i=1;i<=elements.size();i++)
		{
			employeeName.add(findElement("//table[@id='resultTable']/tbody/tr["+i+"]/td[4]").getAttribute("innerText"));
			
		}
		
		//Verify if the added new employee is present in the admin result table
		if(employeeName.contains("Green Yellow"))
		{
			Reporter.log("The newly added employee is present in admin page",true);
			Assert.assertTrue(true);
		}
		else {
			Reporter.log("The newly added employee is not present in admin page",true);
			Assert.fail();
		}
		
		
		
		
		
		
	
		
		
		
	}
	
	@AfterTest()
	public void endTest()
	{
		driver.quit();
	}

}
