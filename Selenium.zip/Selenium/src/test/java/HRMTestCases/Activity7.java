package HRMTestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseClass.BaseClass;

public class Activity7 extends BaseClass{

	
Properties properties=null;
	
	@BeforeTest()
	public void initialising() throws IOException
	{
		properties = new Properties();
		inStream = new FileInputStream("C:\\Users\\ShruthiGokul\\eclipse-workspace\\FrameSelenium\\resources\\input.properties");
		properties.load(inStream);
		OpenBrowser("FIREFOX");
		gotoURL(properties.getProperty("url"));
	}
	
	@Test()
	public  void headerImagetest() throws InterruptedException {
	
		//find and enter credentials in username and passowrd field
		enteringText(findElement(properties.getProperty("username_xpath")), properties.getProperty("username"));
		enteringText(findElement(properties.getProperty("password_xpath")), properties.getProperty("password"));
				
		//click login button
		clickElement(findElement(properties.getProperty("loginbtn_xpath")));
				
		
		//Click on my info
		clickElement(findElement("//a[@id='menu_pim_viewMyDetails']"));
		
		
		//scrolling to the bottom of the page 
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 
		//js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		 js.executeScript("arguments[0].scrollIntoView();", findElement("//a[contains(@href,'Qualifications')]"));
		
		
		//clicking qualifications link
		 findElement("//a[contains(@href,'Qualifications')]").click();
		 
		 //clicking on add button 
		 findElement("//input[@id='addWorkExperience']").click();
		 
		 //entering company, job title
		 enteringText(findElement("//input[@id='experience_employer']"), "CompanyOne");
		 enteringText(findElement("//input[@id='experience_jobtitle']"), "CEO");
		 
		 //click on save button
		 findElement("//input[@id='btnWorkExpSave']").click();
		 
			
	}
	
	@AfterTest()
	public void endTest()
	{
		driver.quit();
	}
}
