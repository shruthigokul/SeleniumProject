package HRMTestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseClass.BaseClass;

public class Activity6 extends BaseClass{

Properties properties=null;
	
	@BeforeTest()
	public void initialising() throws IOException
	{
		properties = new Properties();
		inStream = new FileInputStream("C:\\Users\\ShruthiGokul\\eclipse-workspace\\FrameSelenium\\resources\\input.properties");
		properties.load(inStream);
		OpenBrowser("FIREFOX");
		gotoURL(properties.getProperty("url"));
	}
	
	@Test()
	public  void headerImagetest() throws InterruptedException {
	
		
		//find and enter credentials in username and passowrd field
		enteringText(findElement(properties.getProperty("username_xpath")), properties.getProperty("username"));
		enteringText(findElement(properties.getProperty("password_xpath")), properties.getProperty("password"));
		
		//click login button
		clickElement(findElement(properties.getProperty("loginbtn_xpath")));
		
		//click on Directory from navigatin menu
		clickElement(findElement("//a[@id='menu_directory_viewDirectory']"));
		
		//verify if the directory link is visible
		if(findElement("//a[@id='menu_directory_viewDirectory']").isDisplayed())
		{
			Assert.assertTrue(true);
			Reporter.log("Directory link is visible",true);
		}
		else {
			Assert.fail();
			Reporter.log("Directory link is visible",true);
		}
		
		try {
			WebDriverWait wait=new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.elementToBeClickable((findElement("//a[@id='menu_directory_viewDirectory']"))));
			Reporter.log("The Element is clickable", true);
			Assert.assertTrue(true);
		} catch (Exception e) {
			
			Reporter.log("The Element is not clickable", true);
			Assert.fail();
		}
			
		
		if(findElement("//div[@class='head']/h1").getAttribute("innerText").equals("Search Directory"))
		{
			Reporter.log("The header name is equal to 'Search Directory",true);
			Assert.assertTrue(true);
		}
		else {
			Reporter.log("The header name is not equal to 'Search Directory",true);
			Assert.fail();
		}
		
	}
	
	@AfterTest()
	public void endTest()
	{
		driver.quit();
	}
}
